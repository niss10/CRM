-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 03, 2020 at 03:42 AM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clientmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

DROP TABLE IF EXISTS `tbladmin`;
CREATE TABLE IF NOT EXISTS `tbladmin` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `AdminName` varchar(120) DEFAULT NULL,
  `UserName` varchar(120) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `Email` varchar(120) DEFAULT NULL,
  `Password` varchar(120) DEFAULT NULL,
  `AdminRegdate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`ID`, `AdminName`, `UserName`, `MobileNumber`, `Email`, `Password`, `AdminRegdate`) VALUES
(1, 'Admin', 'admin', 8320098367, 'admin@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2019-10-31 07:01:36');

-- --------------------------------------------------------

--
-- Table structure for table `tblclient`
--

DROP TABLE IF EXISTS `tblclient`;
CREATE TABLE IF NOT EXISTS `tblclient` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `AccountID` int(10) DEFAULT NULL,
  `AccountType` varchar(50) DEFAULT NULL,
  `ContactName` varchar(120) DEFAULT NULL,
  `Occupation` varchar(120) DEFAULT NULL,
  `Address` varchar(200) DEFAULT NULL,
  `City` varchar(120) DEFAULT NULL,
  `State` varchar(120) DEFAULT NULL,
  `ZipCode` int(10) DEFAULT NULL,
  `Workphnumber` bigint(10) DEFAULT NULL,
  `Cellphnumber` bigint(10) DEFAULT NULL,
  `Otherphnumber` bigint(10) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `WebsiteAddress` varchar(200) DEFAULT NULL,
  `Notes` mediumtext,
  `Password` varchar(200) NOT NULL,
  `CreationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `HodName` varchar(50) DEFAULT NULL,
  `empname` varchar(50) DEFAULT NULL,
  `HodEmail` varchar(200) DEFAULT NULL,
  `EmpEmail` varchar(200) DEFAULT NULL,
  `AnnualIncome` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblclient`
--

INSERT INTO `tblclient` (`ID`, `AccountID`, `AccountType`, `ContactName`, `Occupation`, `Address`, `City`, `State`, `ZipCode`, `Workphnumber`, `Cellphnumber`, `Otherphnumber`, `Email`, `WebsiteAddress`, `Notes`, `Password`, `CreationDate`, `HodName`, `empname`, `HodEmail`, `EmpEmail`, `AnnualIncome`) VALUES
(16, 911041605, 'Active Account', 'Magan Patel ', 'Software Engineer', '968,NAVAVAS', 'SONASAN', 'Gujarat', 383210, 8320098898, 8320098898, 8320098898, 'maganpatel123@gmail.com', 'google', '1st customer', 'f925916e2754e5e03f75dd58a5733251', '2020-04-02 08:31:03', 'Nisarg Patel', 'Dev Patel', 'nisargrpatel13@gmail.com', 'devpatel123@gmail.com', '600000'),
(17, 506878444, 'Active Account', 'Chirag Patel ', 'Software Engineer', 'C-3 304 shubham reci near zoo sarthana jakatnaka surat', 'Surat', 'surat', 395006, 7678899880, 7678899880, 7678899880, 'chiragpatel123@gmail.com', 'google', '2nd customer', 'f925916e2754e5e03f75dd58a5733251', '2020-04-02 08:33:44', 'Nisarg Patel', 'Dev Patel', 'nisargrpatel13@gmail.com', 'devpatel123@gmail.com', '300000'),
(18, 169022799, 'Active Account', 'Darshn Suthar', 'Doctor', 'himmatnagar', 'Himmatnagar', 'Gujarat', 383210, 8320098390, 8320098390, 8320098390, 'darshansuthar123@gmail.com', 'google', '4th customer', 'f925916e2754e5e03f75dd58a5733251', '2020-04-02 08:37:08', 'Nisarg Patel', 'Dev Patel', 'nisargrpatel13@gmail.com', 'devpatel123@gmail.com', '1000000'),
(19, 125854259, 'Inactive Account', 'Daksh Patel', 'Software Engineer', '968,NAVAVAS', 'SONASAN', 'Gujarat', 383210, 8320098398, 8320098398, 8320098398, 'nisargrpatel13@gmail.com', 'google', '5th customer', 'f925916e2754e5e03f75dd58a5733251', '2020-04-02 08:38:48', 'Nisarg Patel', 'Dev Patel', 'nisargrpatel13@gmail.com', 'devpatel123@gmail.com', '1200000'),
(20, 420093540, 'Unknown', 'Dhaval Patel', 'Teacher', 'Himmatnagar', 'Himmatnagar', 'Gujarat', 383205, 9428314720, 9428314720, 9428314720, 'nisargrpatel13@gmail.com', 'google', '5th customer', 'f925916e2754e5e03f75dd58a5733251', '2020-04-02 08:41:44', 'Nisarg Patel', 'Dev Patel', 'nisargrpatel13@gmail.com', 'devpatel123@gmail.com', '2000000'),
(21, 419035794, 'Active Account', 'kartik Sutariya', 'Farmer', 'C-3 304 shubham reci near zoo sarthana jakatnaka surat', 'Surat', 'Gujarat', 395006, 8320068987, 8320068987, 8320068987, 'kartikpatel123@gmail.com', 'apna_bazar.com', '3rd customer', 'f925916e2754e5e03f75dd58a5733251', '2020-04-02 08:44:18', 'Parth Patel', 'Kishan Patel', 'nisargrpatel13@gmail.com', 'kishanpatel123@gmail.com', '300000'),
(22, 971441944, 'Inactive Account', 'Rutvik Patel', 'Software Engineer', '968,NAVAVAS', 'SONASAN', 'Gujarat', 383210, 8320098367, 8320098367, 8320098367, 'nisargrpatel1310@gmail.com', 'apna_bazar.com', '7th customer', 'f925916e2754e5e03f75dd58a5733251', '2020-04-02 08:45:31', 'Parth Patel', 'Kishan Patel', 'parthpatel07@gmail.com', 'kishanpatel123@gmail.com', '600000'),
(23, 454234100, 'Contact/Lead', 'Pratik Patel ', 'Farmer', 'C-3 304 shubham reci near zoo sarthana jakatnaka surat', 'Surat', 'Suarat', 395006, 9876543210, 9876543210, 9876543210, 'dishanth304@gmail.com', 'microsoft.com', '8th customer', 'f925916e2754e5e03f75dd58a5733251', '2020-04-02 08:47:56', 'Karnav Patel', 'Kapil Patel', 'nisargrpatel13@gmail.com', 'kapilpatel123@gmail.com', '300000'),
(24, 558595474, 'Active Account', 'Brijesh Patel', 'Doctor', 'Himmatnagar', 'Himmatnagar', 'Gujarat', 383210, 8320098367, 8320098367, 8320098367, 'nisargrpatel13@gmail.com', 'microsoft.com', '9th customer', 'f925916e2754e5e03f75dd58a5733251', '2020-04-02 08:49:49', 'Karnav Patel', 'Kapil Patel', 'karnavpatel123@gmail.com', 'kapilpatel123@gmail.com', '1000000'),
(25, 201889959, 'Contact/Lead', 'Manthan Suthar', 'Teacher', '968,NAVAVAS', 'SONASAN', 'Gujarat', 383210, 8320098367, 8320098367, 8320098367, 'nisargrpatel13@gmail.com', 'microsoft.com', '10th customer', 'f925916e2754e5e03f75dd58a5733251', '2020-04-02 08:51:07', 'Karnav Patel', 'Kapil Patel', 'karnavpatel123@gmail.com', 'kapilpatel123@gmail.com', '200000'),
(26, 311530780, 'Active Account', 'Kishan Patel', 'Software Engineer', '968,NAVAVAS', 'SONASAN', 'Gujarat', 383210, 8320098367, 8320098367, 8320098367, 'nisargrpatel13@gmail.com', 'apna_bazar.com', 'jhjhejf', 'f925916e2754e5e03f75dd58a5733251', '2020-04-02 11:22:24', 'Nisarg Patel', 'Dev Patel', 'nisargrpatel13@gmail.com', 'devpatel123@gmail.com', '600000'),
(27, 611204104, 'Active Account', 'Rutvik Patel', 'Software Engineer', '968,NAVAVAS', 'SONASAN', 'Gujarat', 383210, 8320098367, 8320098367, 8320098367, 'nisargrpatel1310@gmail.com', 'apna_bazar.com', 'add customer', 'f925916e2754e5e03f75dd58a5733251', '2020-04-02 11:34:40', 'Nisarg Patel', 'Dev Patel', 'nisargrpatel13@gmail.com', 'devpatel123@gmail.com', '600000'),
(28, 270810708, 'Active Account', 'Meet Patel', 'Software Engineer', '968,NAVAVAS', 'SONASAN', 'Gujarat', 383210, 8320098367, 8320098367, 8320098367, 'nisargrpatel1311@gmail.com', 'apna_bazar.com', 'add customer', 'f925916e2754e5e03f75dd58a5733251', '2020-04-02 11:46:37', 'Nisarg Patel', 'Dev Patel', 'nisargrpatel13@gmail.com', 'devpatel123@gmail.com', '200000'),
(29, 332617424, 'Active Account', 'Dhruv Patel', 'Software Engineer', '968,NAVAVAS', 'SONASAN', 'Gujarat', 383210, 8320098367, 8320098367, 8320098367, 'nisargrpatel1312@gmail.com', 'apna_bazar.com', 'add customer', 'f925916e2754e5e03f75dd58a5733251', '2020-04-02 12:02:39', 'Nisarg Patel', 'Dev Patel', 'nisargrpatel13@gmail.com', 'devpatel123@gmail.com', '600000'),
(30, 977043594, 'Active Account', 'Nisarg Patel', 'Apna_bazarr', '968,NAVAVAS', 'SONASAN', 'Gujarat', 383210, 8320098367, 8320098367, 8320098367, 'nisargrpatel13@gmail.com', 'apna_bazar.com', 'add customer for apna bazar', 'f925916e2754e5e03f75dd58a5733251', '2020-04-07 12:06:34', 'Parth Patel', 'Kishan Patel', 'parthpatel07@gmail.com', 'kishanpatel123@gmail.com', '600000'),
(31, 330897167, 'Active Account', 'Dax Patel', 'Professor', 'USA', 'NewYork', 'NewYork', 383210, 8320098367, 8320098367, 8320098367, 'daxpatel123@gmail.com', 'haha.com', 'have a great Presentation', 'f925916e2754e5e03f75dd58a5733251', '2020-05-29 04:36:37', 'Nisarg Patel', 'Dev Patel', 'nisargrpatel13@gmail.com', 'kishan123@gmail.com', '10000000');

-- --------------------------------------------------------

--
-- Table structure for table `tblemployee`
--

DROP TABLE IF EXISTS `tblemployee`;
CREATE TABLE IF NOT EXISTS `tblemployee` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `AccountID` int(10) DEFAULT NULL,
  `AccountType` varchar(50) DEFAULT NULL,
  `ContactName` varchar(120) DEFAULT NULL,
  `CompanyName` varchar(120) DEFAULT NULL,
  `Address` varchar(200) DEFAULT NULL,
  `City` varchar(120) DEFAULT NULL,
  `State` varchar(120) DEFAULT NULL,
  `ZipCode` int(10) DEFAULT NULL,
  `Workphnumber` bigint(10) DEFAULT NULL,
  `Cellphnumber` bigint(10) DEFAULT NULL,
  `Otherphnumber` bigint(10) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `WebsiteAddress` varchar(200) DEFAULT NULL,
  `Notes` mediumtext,
  `Password` varchar(200) NOT NULL,
  `CreationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `HodName` varchar(50) DEFAULT NULL,
  `HodEmail` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblemployee`
--

INSERT INTO `tblemployee` (`ID`, `AccountID`, `AccountType`, `ContactName`, `CompanyName`, `Address`, `City`, `State`, `ZipCode`, `Workphnumber`, `Cellphnumber`, `Otherphnumber`, `Email`, `WebsiteAddress`, `Notes`, `Password`, `CreationDate`, `HodName`, `HodEmail`) VALUES
(7, 401068900, 'Active Account', 'Dev Patel', 'google', '968,NAVAVAS', 'SONASAN', 'Gujarat', 383210, 9499782595, 9499782595, 9499782595, 'devpatel123@gmail.com', '968,NAVAVAS', '1st employee', 'f925916e2754e5e03f75dd58a5733251', '2020-04-02 08:15:34', 'Nisarg Patel', 'nisargrpatel13@gmail.com'),
(8, 761532686, 'Active Account', 'Rutvik Patel', 'Google', 'Adajan,surat', 'Surat', 'Gujarat', 395006, 8140137967, 8140137967, 8140137967, 'rutvikpatel123@gmail.com', '968,NAVAVAS', '2nd employee', 'f925916e2754e5e03f75dd58a5733251', '2020-04-02 08:17:21', 'Nisarg Patel', 'nisargrpatel13@gmail.com'),
(9, 785761708, 'Active Account', 'Kishan Patel ', 'apna_bazar', '968,NAVAVAS', 'SONASAN', 'Gujarat', 383210, 9898535556, 9898535556, 9898535556, 'kishanpatel123@gmail.com', 'apna_bazar.com', '3rd employee', 'f925916e2754e5e03f75dd58a5733251', '2020-04-02 08:19:19', 'Parth Patel', 'parthpatel07@gmail.com'),
(10, 119287329, 'Active Account', 'Dishant Patel', 'apna_bazar', 'C-3 304 shubham reci near zoo sarthana jakatnaka surat', 'Surat', 'Gujarat', 395006, 7070899889, 7070899889, 7070899889, 'dishantpatel123@gmail.com', 'apna_bazar.com', '4th employee', 'f925916e2754e5e03f75dd58a5733251', '2020-04-02 08:21:15', 'Parth Patel', 'parthpatel07@gmail.com'),
(11, 828503841, 'Active Account', 'Kapil Patel', 'microsoft', 'gir somnath', 'junagadh', 'Gujarat', 384410, 9988778998, 9988778998, 9988778998, 'kapilpatel123@gmail.com', 'microsoft.com', '5t employee', 'f925916e2754e5e03f75dd58a5733251', '2020-04-02 08:23:54', 'Karnav Patel', 'karnavpatel123@gmail.com'),
(12, 581542837, 'Active Account', 'Ragav Patel', 'microsoft', 'C-3 304 shubham reci near zoo sarthana jakatnaka surat', 'Surat', 'Gujarat', 395006, 7069455467, 7069455467, 7069455467, 'ragavpatel123@gmail.com', 'microsoft.com', '6th employee', 'f925916e2754e5e03f75dd58a5733251', '2020-04-02 08:26:28', 'Karnav Patel', 'karnavpatel123@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tblhod`
--

DROP TABLE IF EXISTS `tblhod`;
CREATE TABLE IF NOT EXISTS `tblhod` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `AccountID` int(10) DEFAULT NULL,
  `AccountType` varchar(50) DEFAULT NULL,
  `ContactName` varchar(120) DEFAULT NULL,
  `CompanyName` varchar(120) DEFAULT NULL,
  `Address` varchar(200) DEFAULT NULL,
  `City` varchar(120) DEFAULT NULL,
  `State` varchar(120) DEFAULT NULL,
  `ZipCode` int(10) DEFAULT NULL,
  `Workphnumber` bigint(10) DEFAULT NULL,
  `Cellphnumber` bigint(10) DEFAULT NULL,
  `Otherphnumber` bigint(10) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `WebsiteAddress` varchar(200) DEFAULT NULL,
  `Notes` mediumtext,
  `Password` varchar(200) NOT NULL,
  `CreationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblhod`
--

INSERT INTO `tblhod` (`ID`, `AccountID`, `AccountType`, `ContactName`, `CompanyName`, `Address`, `City`, `State`, `ZipCode`, `Workphnumber`, `Cellphnumber`, `Otherphnumber`, `Email`, `WebsiteAddress`, `Notes`, `Password`, `CreationDate`) VALUES
(6, 376802919, 'Active Account', 'Nisarg Patel', 'Google', '968,NAVAVAS', 'SONASAN', 'Gujarat', 383210, 8320098367, 8320098367, 8320098367, 'nisargrpatel13@gmail.com', '968,NAVAVAS', '1st Hod', 'f925916e2754e5e03f75dd58a5733251', '2020-04-02 08:09:14'),
(7, 779583587, 'Active Account', 'Parth Patel', 'apna_bazar', 'Royal care Hostel,388421', 'Anand', 'Gujarat', 388421, 9664648490, 9664648490, 9664648490, 'parthpatel07@gmail.com', 'apna_bazar.com', '2nd hod', 'f925916e2754e5e03f75dd58a5733251', '2020-04-02 08:11:34'),
(8, 456061552, 'Active Account', 'Karnav Patel', 'microsoft', 'Nisarg Hostel,changa', 'Anand', 'Gujarat', 388421, 9898898998, 9898898998, 9898898998, 'karnavpatel123@gmail.com', 'xyz.com', '3rd hod', 'f925916e2754e5e03f75dd58a5733251', '2020-04-02 08:13:36');

-- --------------------------------------------------------

--
-- Table structure for table `tblinvoice`
--

DROP TABLE IF EXISTS `tblinvoice`;
CREATE TABLE IF NOT EXISTS `tblinvoice` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `Userid` varchar(120) DEFAULT NULL,
  `ServiceId` varchar(120) DEFAULT NULL,
  `BillingId` varchar(120) DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblinvoice`
--

INSERT INTO `tblinvoice` (`ID`, `Userid`, `ServiceId`, `BillingId`, `PostingDate`) VALUES
(26, '3', '11', '295222211', '2020-04-01 05:46:02'),
(27, '3', '12', '295222211', '2020-04-01 05:46:02'),
(28, '11', '1', '261058744', '2020-04-01 08:27:25'),
(29, '11', '2', '261058744', '2020-04-01 08:27:25'),
(30, '11', '1', '797747281', '2020-04-02 04:25:04'),
(31, '11', '2', '797747281', '2020-04-02 04:25:04'),
(32, '11', '3', '797747281', '2020-04-02 04:25:04'),
(33, '11', '4', '797747281', '2020-04-02 04:25:04'),
(34, '3', '1', '344930311', '2020-04-02 04:58:32'),
(35, '6', '14', '653121861', '2020-04-02 09:07:46'),
(36, '6', '15', '653121861', '2020-04-02 09:07:46'),
(37, '6', '16', '653121861', '2020-04-02 09:07:47'),
(38, '17', '14', '645854777', '2020-04-02 09:08:10'),
(39, '17', '15', '645854777', '2020-04-02 09:08:10'),
(40, '7', '14', '942321380', '2020-04-07 11:52:46'),
(41, '16', '15', '434883987', '2020-04-07 12:01:37'),
(42, '30', '24', '262197167', '2020-04-07 12:08:23'),
(43, '16', '20', '152712016', '2020-05-29 04:08:37'),
(44, '16', '22', '152712016', '2020-05-29 04:08:37'),
(45, '16', '27', '130280550', '2020-05-29 04:10:27'),
(46, '7', '27', '987295526', '2020-05-29 04:10:58'),
(47, '7', '28', '987295526', '2020-05-29 04:10:58'),
(48, '7', '29', '987295526', '2020-05-29 04:10:58'),
(49, '16', '27', '983625435', '2020-05-29 08:42:56'),
(50, '16', '28', '983625435', '2020-05-29 08:42:56'),
(51, '16', '29', '983625435', '2020-05-29 08:42:56'),
(52, '16', '27', '433984228', '2020-06-26 04:09:40'),
(53, '16', '28', '433984228', '2020-06-26 04:09:40');

-- --------------------------------------------------------

--
-- Table structure for table `tblpage`
--

DROP TABLE IF EXISTS `tblpage`;
CREATE TABLE IF NOT EXISTS `tblpage` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `PageType` varchar(120) DEFAULT NULL,
  `PageTitle` varchar(200) DEFAULT NULL,
  `PageDescription` mediumtext,
  `Email` varchar(120) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `UpdationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblservices`
--

DROP TABLE IF EXISTS `tblservices`;
CREATE TABLE IF NOT EXISTS `tblservices` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `ServiceName` varchar(200) DEFAULT NULL,
  `ServicePrice` varchar(200) DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblservices`
--

INSERT INTO `tblservices` (`ID`, `ServiceName`, `ServicePrice`, `CreationDate`) VALUES
(27, 'IPO', '100', '2020-05-29 04:09:20'),
(28, 'mediclaim', '50', '2020-05-29 04:09:30'),
(29, 'stock', '20', '2020-05-29 04:09:46');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
